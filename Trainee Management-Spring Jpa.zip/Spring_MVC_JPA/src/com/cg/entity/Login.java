package com.cg.entity;

public class Login {

}
